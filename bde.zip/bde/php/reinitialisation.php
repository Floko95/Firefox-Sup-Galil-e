<?php require_once("include/serveur.php"); ?>

<?php 
session_start();
if (isset($_SESSION['id'])) {
	header ('Location: accueil.php');
	exit();
} 
?>

<?php require_once("include/reinitialisation.php"); ?>

<!DOCTYPE html>
<html>
	<body>

		<!-- Réinitialiser le mot de passe -->
		<form action="" method="post">
			<input type="mail" name="mailUniv" placeholder="Adresse mail universitaire" required /><br>
			<input type="submit" name="reinitialisation" value="Valider" />
		</form>
		<?php if (isset($erreurReinitialisation)) echo $erreurReinitialisation; ?>

	</body>
</html>
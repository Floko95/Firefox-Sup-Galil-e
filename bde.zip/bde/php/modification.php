<?php require_once("include/serveur.php"); ?>

<?php 
session_start();
if (isset($_SESSION['id'])) {
	header ('Location: accueil.php');
	exit();
} 
?>

<?php require_once("include/modification.php"); ?>

<!DOCTYPE html>
<html>
	<body>

		<!-- Changer le mot de passe -->
		<form action="" method="post">
			<input type="password" name="mdp" placeholder="Mot de passe" maxlength="30" required /><br>
			<input type="password" name="confirmation" placeholder="Mot de passe" maxlength="30" required /><br>
			<input type="submit" name="modification" value="Valider" />
		</form>
		<?php if (isset($erreurModification)) echo $erreurModification; ?>

	</body>
</html>
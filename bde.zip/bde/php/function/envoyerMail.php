<!-- ENVOI D'UN MAIL A UN ETUDIANT -->

<?php

$to      = 'personne@example.com';
$subject = 'le sujet';
$message = 'Bonjour !';
$headers = 'From: webmaster@example.com' . "\r\n" .
			'Reply-To: webmaster@example.com' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();

	
	 
function envoyerMail($to, $link, $code, $type) {
	if ($type == 1) { 		// Si c'est un mail pour valider l'inscription
		$subject = ...
		$message = ...
	}
	else if ($type == 2) { 	// Si c'est un mail pour réinitialiser le mot de passe
		$subject = ...
		$message = ...
	}
	mail($to, $subject, $message, $headers);
}

 ?>
<?php require_once("include/serveur.php"); ?>

<?php
session_start();
session_destroy();
header('location: accueil.php');
exit;
?>

<?php require_once("include/serveur.php"); ?>

<?php 
session_start();
if (isset($_SESSION['id'])) {
	header ('Location: accueil.php');
	exit();
} 
?>

<?php require_once("include/connexion.php"); ?>

<!DOCTYPE html>
<html>
	<body>

		<!-- Se connecter -->
		<form action="connexion.php" method="post">
			<input type="mail" name="mailUniv" placeholder="Adresse universitaire" required /><br>
			<input type="password" name="mdp" placeholder="Mot de passe" maxlength="30" required /><br>
			<input type="submit" name="connexion" value="Valider" />
		</form>
		<?php if (isset($erreurConnexion)) echo $erreurConnexion; ?>

	</body>
</html>
<!-- INSCRIPTION -->

<?php // HACHER CODE
// L'adresse perso peut etre n'importe quoi ...
// Pb si on met pas d'adresse perso

if (isset($_POST['inscription']) && $_POST['inscription'] == 'Valider') {
	if (isset($_POST['prenom'], $_POST['nom'], $_POST['numero'], $_POST['mailUniv'], $_POST['formation'], $_POST['promotion'], $_POST['mdp'], $_POST['confirmation']) && !empty($_POST['prenom']) && !empty($_POST['nom']) && !empty($_POST['numero']) && !empty($_POST['mailUniv']) && !empty($_POST['formation']) && !empty($_POST['promotion']) && !empty($_POST['mdp']) && !empty($_POST['confirmation'])) {
	
		if (get_magic_quotes_gpc())
		{
			$_POST['prenom'] = stripslashes($_POST['prenom']);
			$_POST['nom'] = stripslashes($_POST['nom']);
			$_POST['numero'] = stripslashes($_POST['numero']);
			$_POST['mailUniv'] = stripslashes($_POST['mailUniv']);
			if (isset($_POST['mailPerso'])) {
				$_POST['mailPerso'] = stripslashes($_POST['mailPerso']);
			}
			$_POST['mdp'] = stripslashes($_POST['mdp']);
			$_POST['confirmation'] = stripslashes($_POST['confirmation']);
		}
		
		if (preg_match('#^([0-9]{8})$#', $_POST['numero'])){
			if (preg_match('#^([a-z]*.[a-z]*@edu.univ-paris13.fr)$#', $_POST['mailUniv'])) {
				if (isset($_POST['mailPerso']) && !empty($_POST['mailPerso']) && preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i', $_POST['mailPerso'])) {
					if ($_POST['mdp'] == $_POST['confirmation']) {
						if(strlen($_POST['mdp']) >= 6) {
					
							if (isset($_POST['mailPerso']) && !empty($_POST['mailPerso'])) {
								$req = $bdd->prepare('SELECT COUNT(*) FROM ETUDIANTS WHERE (mailUniv = ? OR mailPerso = ?) AND etat > 0');
								$req->execute(array($_POST['mailUniv'], $_POST['mailPerso']));
							}
							else {
								$req = $bdd->prepare('SELECT COUNT(*) FROM ETUDIANTS WHERE mailUniv = ? AND etat > 0');
								$req->execute(array($_POST['mailUniv']));
							}
							$data = $req->fetch();
							if ($data[0] == 0) {
								
								$req = $bdd->prepare('INSERT INTO ETUDIANTS(mailUniv, mailPerso, nom, prenom, numero, mdp, formation, promotion, dateInscription) VALUES(:mailUniv, :mailPerso, :nom, :prenom, :numero, :mdp, :formation, :promotion, :dateInscription)');
								$req->execute(array(
								'mailUniv' => $_POST['mailUniv'],
								'mailPerso' => $_POST['mailPerso'],
								'nom' => $_POST['nom'],
								'prenom' => $_POST['prenom'],
								'numero' => $_POST['numero'],
								'mdp' => sha1($_POST['mdp']),
								'formation' => $_POST['formation'],
								'promotion' => $_POST['promotion'],
								'dateInscription' => date('Y-m-d H:i:s')));
								
								# L'étudiant en question est le dernier étudiant à s'être inscrit avec cette adresse mail
								$req = $bdd->prepare('SELECT * FROM ETUDIANTS WHERE mailUniv = ? ORDER BY dateInscription DESC');
								$req->execute(array($_POST['mailUniv']));
								$etudiant = $req->fetch();
								
								# On génère un code de confirmation
								do{
									$code = bin2hex(openssl_random_pseudo_bytes(5, $b));
									if ($b == true){
										$req = $bdd->prepare('SELECT COUNT(*) FROM CODES WHERE code = ?');
										$req->execute(array($code));
										$occurence = $req->fetch();
										if ($occurence[0] > 0) {
											$b = false;
										}
									}
								}
								while ($b == false);
								
								# On insère ce code (hâché) dans la table des codes
								$req = $bdd->prepare('INSERT INTO CODES(id, code, type, dateMail) VALUES(:id, :code, :type, :dateMail)');
								$req->execute(array(
								'id' => $etudiant['id'],
								'code' => $code,
								'type' => 1,
								'dateMail' => date('Y-m-d H:i:s')));
								
								# On envoie un mail contenant le code à l'étudiant sur son adresse universitaire
								// envoi d'un mail
		
			
								
								# On redirige l'étudiant vers une page pour qu'il puisse insérer le code reçu par mail
								header('Location: verification.php?id='.$etudiant['id']);
								exit();
							}
							else {
								$erreurInscription = 'Un étudiant inscrit possède déjà cette adresse mail';
							}
						}
						else {
							$erreurInscription = "Le mot de passe doit comporter au moins 6 caractères.";
						}
					}
					else {
						$erreurInscription = "Les deux mots de passe sont différents.";
					}
				}
				else {
					$erreurInscription = "L'adresse personnelle n'est sémantiquement pas correcte.";
				}
			}
			else {
				$erreurInscription = "Ceci n'est pas une adresse universitaire.";
			}
		}
		else {
			$erreurInscription = "Numéro d'étudiant invalide. (8 chiffres)";
		}
	}
	else {
		$erreurInscription = 'Au moins un des champs obligatoires est vide.';
	}
}
?>
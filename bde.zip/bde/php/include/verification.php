<!-- VERIFICATION D'UN CODE -->

<?php // HACHER CODE *2

if (isset($_POST['verification']) && $_POST['verification'] == 'Valider') {
	if (isset($_POST['code'], $_GET['id']) && !empty($_POST['code']) && !empty($_GET['id'])) {

		if(get_magic_quotes_gpc())
		{
			$_POST['code'] = stripslashes($_POST['code']);
			$_GET['id'] = stripslashes($_GET['id']);
		}
		
		# On vérifie que le code entré est valide (et est le dernier code créé pour cet étudiant)
		$req = $bdd->prepare('SELECT COUNT(*) FROM CODES C1 WHERE C1.id = ? AND C1.code = ? AND C1.dateMail = (SELECT MAX(dateMail) FROM CODES C2 WHERE C2.id = C1.id)');
		$req->execute(array($_GET['id'], $_POST['code']));
		$data = $req->fetch();

		if ($data[0] == 1) {
			$req = $bdd->prepare('SELECT * FROM CODES WHERE id = ? AND code = ?');
			$req->execute(array($_GET['id'], $_POST['code']));
			$data = $req->fetch();
			
			# Si c'est un code pour valider l'inscription
			if ($data['type'] == 1) {
				# On met l'état de l'étudiant à 1 (en attente de validation de l'inscription par un admin)
				$req = $bdd->prepare('UPDATE ETUDIANTS SET etat = 1 WHERE id = ?');
				$req->execute(array($_GET['id']));
				
				# On récupère les informations de cet étudiant
				$req = $bdd->prepare('SELECT * FROM ETUDIANTS WHERE id = ?');
				$req->execute(array($_GET['id']));
				$etudiant = $req->fetch();
				
				# On supprime tous les comptes qui ont la même adresse universitaire et sont encore dans l'état 0 (en attente de validation de l'inscription par un l'étudiant)
				# Il peut en effet y avoir plusieurs entrées dans la table ETUDIANTS avec la même adresse universitaire
				# En revanche, il ne peut pas y avoir plusieurs entrées avec la même adresse universitaire et dans des états > 0 
				$req = $bdd->prepare('DELETE FROM ETUDIANTS WHERE mailUniv = ? AND etat = 0');
				$req->execute(array($etudiant['mailUniv'])); // fonctionne pas ? cascade ?
				
				# On supprime le code pour qu'il ne puisse pas être réutilisé
				$req = $bdd->prepare('DELETE FROM CODES WHERE id = ?');
				$req->execute(array($etudiant['id']));
				
				# On connecte l'étudiant
				session_start();
				$_SESSION['id'] = $etudiant['id'];
				$_SESSION['prenom'] = $etudiant['prenom'];
				$_SESSION['nom'] = $etudiant['nom'];
				$_SESSION['formation'] = $etudiant['formation'];
				$_SESSION['etat'] = $etudiant['etat'];
				header('Location: accueil.php');
				exit();
			}
			# Si c'est un code pour réinitialiser le mot de passe
			else if ($data['type'] == 2) {
				// ???
				header('Location: modification.php?id='.$_GET['id'].'&code='.$_POST['code']);
				exit();
			}
		}
		else {
			$erreurVerification = 'Code invalide.';
		}
	}
	else {
		$erreurVerification = 'Code invalide.';
	}
}
?>
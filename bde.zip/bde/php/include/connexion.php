<!-- CONNEXION -->

<?php
if (isset($_POST['connexion']) && $_POST['connexion'] == 'Valider') {
	if (isset($_POST['mailUniv'], $_POST['mdp']) && !empty($_POST['mailUniv']) && !empty($_POST['mdp'])) {

		if (get_magic_quotes_gpc())
		{
			$_POST['mailUniv'] = stripslashes($_POST['mailUniv']);
			$_POST['mdp'] = stripslashes($_POST['mdp']);
		}
		
		# On vérifie que l'identifiant et le mot de passe sont valides
		$req = $bdd->prepare('SELECT COUNT(*) FROM ETUDIANTS WHERE mailUniv = ? and mdp = ? and etat > 0');
		$req->execute(array($_POST['mailUniv'], sha1($_POST['mdp'])));
		$data = $req->fetch();
		
		if ($data[0] == 1) {
			$req = $bdd->prepare('SELECT * FROM ETUDIANTS WHERE mailUniv = ? and mdp = ? and etat > 0');
			$req->execute(array($_POST['mailUniv'], sha1($_POST['mdp'])));
			$data = $req->fetch();
			
			# On connecte l'étudiant
			session_start();
			$_SESSION['id'] = $data['id'];
			$_SESSION['prenom'] = $data['prenom'];
			$_SESSION['nom'] = $data['nom'];
			$_SESSION['formation'] = $data['formation'];
			$_SESSION['etat'] = $data['etat'];
			header('Location: accueil.php');
			exit();
		}
		else {
			$erreurConnexion = 'Identifiant ou mot de passe invalide.';
		}
	}
	else {
		$erreurConnexion = 'Au moins un des champs est vide.';
	}
}
?>
<!-- REINITIALISATION D'UN MOT DE PASSE -->

<?php // HACHER CODE

if (isset($_POST['reinitialisation']) && $_POST['reinitialisation'] == 'Valider') {
	if (isset($_POST['mailUniv']) && !empty($_POST['mailUniv'])) {
		
		if(get_magic_quotes_gpc())
		{
			$_POST['mailUniv'] = stripslashes($_POST['mailUniv']);
		}
		
		# On vérifie qu'à l'adresse mail universitaire est associé un compte d'état > 0
		$req = $bdd->prepare('SELECT COUNT(*) FROM ETUDIANTS WHERE mailUniv = ? AND etat > 0');
		$req->execute(array($_POST['mailUniv']));
		$data = $req->fetch();
		
		if ($data[0] == 1) {
			$req = $bdd->prepare('SELECT * FROM ETUDIANTS WHERE mailUniv = ? AND etat > 0');
			$req->execute(array($_POST['mailUniv']));
			$etudiant = $req->fetch();
			
			# On supprime les anciens codes associés au compte de cet étudiant avant d'en créer un nouveau
			# On fait en effet en sorte qu'un étudiant ait au plus un code stocké dans la table
			# Ainsi, lorqu'un étudiant génère un code, les anciens ne sont alors plus valides
			$req = $bdd->prepare('DELETE FROM CODES WHERE id = ?');
			$req->execute(array($etudiant['id']));
			
			# On génère un code de confirmation
			do{
				$code = bin2hex(openssl_random_pseudo_bytes(5, $b));
				if ($b == true){
					$req = $bdd->prepare('SELECT COUNT(*) FROM CODES WHERE code = ?');
					$req->execute(array($code));
					$occurence = $req->fetch();
					if ($occurence[0] > 0) {
						$b = false;
					}
				}
			}
			while ($b == false);
								
			# On insère ce code (hâché) dans la table des codes
			$req = $bdd->prepare('INSERT INTO CODES(id, code, type, dateMail) VALUES(:id, :code, :type, :dateMail)');
			$req->execute(array(
			'id' => $etudiant['id'],
			'code' => $code,
			'type' => 2,
			'dateMail' => date('Y-m-d H:i:s')));
								
			// Envoyer un mail
			
			header('Location: verification.php?id='.$etudiant['id']);
			exit();
		}
		else {
			$erreurReinitialisation = 'Adresse mail universitaire invalide.';
		}
	}
	else {
		$erreurReinitialisation = 'Aucune adresse mail entrée.';
	}
}
		
?>
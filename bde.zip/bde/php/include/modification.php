<!-- INSERTION D'UN NOUVEAU MOT DE PASSE -->

<?php

if (isset($_POST['modification']) && $_POST['modification'] == 'Valider') {
	if (isset($_POST['mdp'], $_POST['confirmation'], $_GET['id'], $_GET['code']) && !empty($_POST['mdp']) && !empty($_POST['confirmation']) && !empty($_GET['id']) && !empty($_GET['code'])) {
		
		if(get_magic_quotes_gpc())
		{
			$_POST['mdp'] = stripslashes($_POST['mdp']);
			$_POST['confirmation'] = stripslashes($_POST['confirmation']);
			$_GET['id'] = stripslashes($_GET['id']);
			$_GET['code'] = stripslashes($_GET['code']);
		}
		
		# On vérifie que le code et l'id associé sont valides
		$req = $bdd->prepare('SELECT COUNT(*) FROM CODES WHERE id = ? AND code = ? and type = 2');
		$req->execute(array($_GET['id'], $_GET['code']));
		$data = $req->fetch();
		
		if ($data[0] == 1) {
			if ($_POST['mdp'] == $_POST['confirmation']) {
				if(strlen($_POST['mdp']) >= 6) {
					# On met à jour le mot de passe de l'étudiant
					$req = $bdd->prepare('UPDATE ETUDIANTS SET mdp = ? WHERE id = ?');
					$req->execute(array(sha1($_POST['mdp']), $_GET['id']));
					
					# On supprime le code pour qu'il ne puisse pas être réutilisé
					$req = $bdd->prepare('DELETE FROM CODES WHERE id = ?');
					$req->execute(array($_GET['id']));
					
					# On connecte l'étudiant
					$req = $bdd->prepare('SELECT * FROM ETUDIANTS WHERE id = ?');
					$req->execute(array($_GET['id']));
					$etudiant = $req->fetch();
					session_start();
					$_SESSION['id'] = $etudiant['id'];
					$_SESSION['prenom'] = $etudiant['prenom'];
					$_SESSION['nom'] = $etudiant['nom'];
					$_SESSION['formation'] = $etudiant['formation'];
					$_SESSION['etat'] = $etudiant['etat'];
					header('Location: accueil.php');
					exit();
				}
				else {
					$erreurModification = "Le mot de passe doit comporter au moins 6 caractères.";
				}
			}
			else {
				$erreurModification = "Les deux mots de passe sont différents.";
			}
		}
		else {
			$erreurModification = 'Une erreur est survenue.';
		}
	}
	else {
		$erreurModification = 'Une information est manquante.';
	}
}



?>
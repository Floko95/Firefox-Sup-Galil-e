<?php require_once("include/serveur.php"); ?>

<?php 
session_start();
if (isset($_SESSION['id'])) {
	header ('Location: accueil.php');
	exit();
} 
?>

<?php require_once("include/inscription.php"); ?>

<!DOCTYPE html>
<html>
	<body>

		<!-- S'inscrire -->
		<form action="inscription.php" method="post">
			<input type="text" name="prenom" placeholder="Prénom" value="<?php if (isset($_POST['prenom'])) echo $_POST['prenom']; ?>" maxlength="20" required /><br>
			<input type="text" name="nom" placeholder="Nom" maxlength="20" required /><br>
			<input type="text" name="numero" placeholder="Numéro d'étudiant" maxlength="20" required /><br>
			<input type="mail" name="mailUniv" placeholder="Adresse mail universitaire" required /><br>
			<input type="mail" name="mailPerso" placeholder="Adresse mail personnelle" /><br>
			<select name="formation" size="1">
				<option>CP2I
				<option>ENER
				<option>INFO
				<option>MACS
				<option>TELE
			</select>
			<select name="promotion" size="1">
				<option>2019
				<option>2020
				<option>2021
				<option>2022
				<option>2023
			</select><br>
			<input type="password" name="mdp" placeholder="Mot de passe" maxlength="30" required /><br>
			<input type="password" name="confirmation" placeholder="Confirmer le mot de passe" maxlength="30" required /><br>
			<input id="check" type="checkbox" name="regagree" value="valeur" /> Je certifie avoir pris connaissance du règlement
			<input type="submit" name="inscription" value="Valider" />
		</form>
		<?php if (isset($erreurInscription)) echo $erreurInscription; ?>

	</body>
</html>
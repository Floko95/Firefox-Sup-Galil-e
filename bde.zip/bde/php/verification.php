<?php require_once("include/serveur.php"); ?>

<?php 
session_start();
if (isset($_SESSION['id'])) {
	header ('Location: accueil.php');
	exit();
} 
?>

<?php require_once("include/verification.php"); ?>

<!DOCTYPE html>
<html>
	<body>

		<!-- Insérer un code reçu par mail -->
		<form action="" method="post">
			<input type="text" name="code" placeholder="Code" required /><br>
			<input type="submit" name="verification" value="Valider" />
		</form> <!-- Rajouter un post d'id invisible -->
		<?php if (isset($erreurVerification)) echo $erreurVerification; ?>

	</body>
</html>
<?php require_once("include/serveur.php"); ?>

<?php session_start(); ?>


<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</head>
	<body>
	
					<a href="inscription.php">Inscription</a>
					<a href="connexion.php">Connexion</a>
					<a href="verification.php">Verification</a>
					<a href="reinitialisation.php">Reinitialisation</a>
					<a href="modification.php">Modification</a>
					<a href="deconnexion.php">Deconnexion</a>
	
					<!-- Insérer un code reçu par mail -->
					<form action="home.php" method="post">
						<input type="text" name="code" placeholder="Code" required /><br>
						<input type="submit" name="verification" value="Valider" />
					</form> <!-- Rajouter un post d'id invisible -->
					<?php if (isset($erreurVerification)) echo $erreurVerification; ?>
					
					<br><br><br>
					
					<!-- Réinitialiser le mot de passe -->
					<form action="home.php" method="post">
						<input type="mail" name="mailUniv" placeholder="Adresse mail universitaire" required /><br>
						<input type="submit" name="reinitialisation" value="Valider" />
					</form>
					<?php if (isset($erreurReinitialisation)) echo $erreurReinitialisation; ?>
					
					<br><br><br>
					
					<!-- Changer le mot de passe -->
					<form action="home.php" method="post">
						<input type="password" name="mdp" placeholder="Mot de passe" maxlength="30" required /><br>
						<input type="password" name="confirmation" placeholder="Mot de passe" maxlength="30" required /><br>
						<input type="submit" name="modification" value="Valider" />
					</form>
					<?php if (isset($erreurModification)) echo $erreurModification; ?>
					
					<br><br><br>
					
					<!-- Se connecter -->
					<form action="accueil.php" method="post">
						<input type="mail" name="mailUniv" placeholder="Adresse universitaire" required /><br>
						<input type="password" name="mdp" placeholder="Mot de passe" maxlength="30" required /><br>
						<input type="submit" name="connexion" value="Valider" />
					</form>
					<?php if (isset($erreurConnexion)) echo $erreurConnexion; ?>
					
					<br><br><br>

					<!-- S'inscrire -->
					<form action="accueil.php" method="post">
						<input type="text" name="prenom" placeholder="Prénom" value="<?php if (isset($_POST['prenom'])) echo $_POST['prenom']; ?>" maxlength="20" required /><br>
						<input type="text" name="nom" placeholder="Nom" maxlength="20" required /><br>
						<input type="text" name="numero" placeholder="Numéro d'étudiant" maxlength="20" required /><br>
						<input type="mail" name="mailUniv" placeholder="Adresse mail universitaire" required /><br>
						<input type="mail" name="mailPerso" placeholder="Adresse mail personnelle" /><br>
						<select name="formation" size="1">
							<option>CP2I
							<option>ENER
							<option>INFO
							<option>MACS
							<option>TELE
						</select>
						<select name="promotion" size="1">
							<option>2019
							<option>2020
							<option>2021
							<option>2022
							<option>2023
						</select><br>
						<input type="password" name="mdp" placeholder="Mot de passe" maxlength="30" required /><br>
						<input type="password" name="confirmation" placeholder="Confirmer le mot de passe" maxlength="30" required /><br>
						<input id="check" type="checkbox" name="regagree" value="valeur" /> Je certifie avoir pris connaissance du règlement
						<input type="submit" name="inscription" value="Valider" />
					</form>
					<?php if (isset($erreurInscription)) echo $erreurInscription; ?>
					
					

	</body>
</html>
